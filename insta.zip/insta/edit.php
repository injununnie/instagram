<?php
session_start();
if (!isset($_SESSION['login'])){
    header("location:login.php?pesan=login");
}
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <h1>Edit</h1>
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

        <label for="">Foto</label>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" ><br><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt="" ><br>
        
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        
        <input type="submit" value="Update" name="update">
    </form>
</body>
</html>

<?php } ?>