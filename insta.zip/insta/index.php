<?php
session_start();
if (!isset($_SESSION['login'])){
    header("location:login.php?pesan=login");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ootdgram</title>
    <link rel="shortcut icon" href="img/favicon.jpeg" type="image/x-icon">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
    .card-img-top {
        transition: transform 0.3s;
    }

    .card-img-top:hover {
        transform: scale(1.1);
    }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg  fixed-top " style="background-color:#FCC3BB;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"></a>
    <img src="img/logo.png" alt="" width="190px">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Beranda</a>
        </li>
      </ul>
      <span class="navbar-text">
      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
      <i class="fa-solid fa-plus"></i>
</button> |
        <a href="logout.php"><button class="btn  btn-danger"><i class="fa-solid fa-right-from-bracket"></i></button></a>
      </span>
    </div>
  </div>
</nav> <br> <br> <br>

<div class="container mt-4 ">
  <div class="row">
    <!-- Tampilan Data yang Sudah Ada -->
    <?php while ($post = mysqli_fetch_assoc($query)) { ?>
      <center>
      <div class="col-md-4">
        <div class="card mb-4">
          <img src="images/<?= $post['foto'] ?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?= $post['caption'] ?></h5>
            <p class="card-text"><?= $post['lokasi'] ?></p>
            <button  class="btn btn-success"><i class="fas fa-edit" data-bs-toggle="modal" data-bs-target="#edit<?= $post['no']?>"></i></button> |
            <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-danger"><i class="fa-solid fa-trash"></i></a>
          </div>
        </div>
      </div>
      </center>



    <!-- modal edit -->
    <div class="modal fade" data-bs-backdrop="static"  id="edit<?=$post['no']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Form Edit</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data" autocomplete="off">
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
      <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
                <div class="form-group">
                    <label for="">Foto</label>
                    <input type="file" class = "form-control" name="foto" value="<?=$post['foto'] ?>"><br>
                    <img src="images/<?= $post['foto'] ?>" width="200" alt=""><br>
                </div><br>
                  <div class="form-group">
                    <label for="">Caption</label>
                    <textarea type="text" class="form-control" name="caption" id=""><?=$post['caption']?></textarea>
                </div><br>
                <div class="form-group">
                  <label for="">Lokasi</label>
                  <input type="text" class = "form-control" name="lokasi" placeholder="Masukkan data"  value="<?=$post['lokasi']?>"><br>
                  </div>
      </div>
      <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      <button type="submit" class= "btn btn-primary" name="update">Update</button>
            </form>
      </div>
    </div>
  </div>
</div>
    <?php } ?>
    </div><br><br>
    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="" class="form-label">foto</label><br>
        <input class="form-control" type="file" name="foto" id="" required><br><br>

        <label for="" class="form-label">Caption</label><br>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label for="" class="form-label">Lokasi</label><br>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="submit" name="simpan"></input>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>
  </div>
</div>

</body>
</html>

