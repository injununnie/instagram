<?php
session_start();
if (!isset($_SESSION['login'])){
    header("location:login.php?pesan=login");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <div class="container">
    <h1>Tambah</h1>
    <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">
        <label for="" class="form-label">Foto</label>
        <input type="file" name="foto" id="" class="form-control" required ><br>

        <label for="" class="form-label">Caption</label>
        <input type="text" name="caption" id="" autocomplete="off" class="form-control"><br>

        <label for="" class="form-label">Lokasi</label>
        <input type="text" name="lokasi" id="" autocomplete="off" class="form-control"><br>
        
        <input type="submit" value="Simpan" name="simpan" class="btn btn-sm btn-primary">
    </form>
    </div>
</body>
</html>

